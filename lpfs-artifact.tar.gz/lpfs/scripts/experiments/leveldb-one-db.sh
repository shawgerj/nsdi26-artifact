#!/bin/bash

# these are average block sizes
# for fingerprinting mode, min is always half and max is always double
BLKSZS=('512' '1024' '2048' '4096')
MODES=('fingerprint')

for blksz in "${BLKSZS[@]}"; do
    for mode in "${MODES[@]}"; do
        ./reset-clean.sh $blksz $mode
        sleep 2
        ls mnt
        ./leveldb-test/db-eval-one-db
        ls mnt
        mv log.out leveldb-single-$blksz-blocksz.dat
    done
done

echo "work completed"
