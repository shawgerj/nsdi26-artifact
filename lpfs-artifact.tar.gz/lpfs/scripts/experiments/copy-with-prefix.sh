#!/bin/bash

# these are average block sizes
# for fingerprinting mode, min is always half and max is always double
BLKSZS=('512')
MODES=('static' 'fingerprint')
PREFIXSZS=('16' '32' '64' '128' '256' '512') # in bytes
PREFIXSZS=('16')

for blksz in "${BLKSZS[@]}"; do
    for mode in "${MODES[@]}"; do
        for prefix in "${PREFIXSZS[@]}"; do
            ./reset-clean.sh $blksz $mode
            sleep 2
            ls mnt
            dd if=/dev/urandom of=mnt/rand-$((1024*1024)) bs=1M count=1
            ls mnt
            ./data-writer -p $prefix -i mnt/rand-$((1024*1024)) -o mnt/rand-$((1024*1024))-2
            ls mnt
            mv log.out cp-prefix-$mode-$blksz-prefix${prefix}.dat
        done
    done
done

echo "work completed"
