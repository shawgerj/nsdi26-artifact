#!/bin/bash

# these are average block sizes
# for fingerprinting mode, min is always half and max is always double
BLKSZS=('512' '1024' '2048' '4096')
MODES=('static' 'fingerprint')
FILESZS=(1 10 100) # in MB

for blksz in "${BLKSZS[@]}"; do
    for mode in "${MODES[@]}"; do
        for sz in "${FILESZS[@]}"; do
            ./reset-clean.sh $blksz $mode
            sleep 2
            ls mnt
            dd if=/dev/urandom of=mnt/rand-$((1024*1024*$sz)) bs=1M count=$sz
            ls mnt
            cp mnt/rand-$((1024*1024*$sz)) mnt/rand-$((1024*1024*$sz))-2
            ls mnt
            mv log.out cp-$mode-$blksz-${sz}MB.dat
        done
    done
done

echo "work completed"
