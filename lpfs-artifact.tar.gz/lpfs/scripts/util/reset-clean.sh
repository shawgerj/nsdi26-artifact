#!/bin/bash

rootdir=$1
blksize=$2
worker=$3

# cleanup any previous FS
fusermount -u $rootdir/mnt
rm -f log.out
rm -f disk.img
rm -rf $rootdir/fs
sleep 1

# create 1GB "disk"
dd if=/dev/zero of=$rootdir/disk.img bs=1M count=1024
sleep 1

# mkfs
$rootdir/mkfs -d $rootdir/disk.img -i 256 -b 200000
sleep 1

# start LPFS
$rootdir/lpfs -d $rootdir/disk.img -l $rootdir/log.out -t $worker -b $blksize -s -m $rootdir/mnt
