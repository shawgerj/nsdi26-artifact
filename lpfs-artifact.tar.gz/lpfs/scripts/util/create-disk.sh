#!/bin/bash

dd if=/dev/zero of=disk.img bs=1M count=1024
