#!/bin/bash

./mkfs -d disk.img -i 256 -b 200000
