#!/bin/bash

PROJ_ROOT=$(pwd)
MOUNT_DIR=mnt

# args: chunktype leveldb-value-size chunk-size
run_workload () {
    # args for reset-clean.sh: rootdir value_size worker_type
    $PROJ_ROOT/scripts/util/reset-clean.sh $PROJ_ROOT $3 $1
    sleep 10

    if [[ "$1" == "apphint" ]]; then
       $PROJ_ROOT/dbeval -v $2 -n 2 -h
    else
	$PROJ_ROOT/dbeval -v $2 -n 2
    fi
    
    sleep 2
    ls $MOUNT_DIR
    mv log.out lpfs-2db-$2-valuesize-$3-blksize-$1.dat
    sleep 1
    umount $MOUNT_DIR
}

mkdir -p $MOUNT_DIR

echo $PROJ_ROOT

for i in $(seq 10 15); do
    # rabin
    for j in $(seq $((i-2)) $i); do
	run_workload fingerprint $((2**i)) $((2**j))
    done

    # apphint
    run_workload apphint $((2**i)) $((2**i))

    # static
    run_workload static $((2**i)) $((2**i))    
done
