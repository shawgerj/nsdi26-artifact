#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <rabinpoly.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
//#include "circbuf/circbuf.h"


#define ALLDATA (8 * 1024 * 1024)

unsigned int window_size = 32;
size_t min_block_size = 512;
size_t avg_block_size = 1024;
size_t max_block_size = 2048;

char* data_buffer;
struct circbuf* cb;
size_t* blocks_dist;

// fill the circbuf with data from data_buffer until it is all gone,
// then mark the circbuf as EOF
void* producer_thread(void* arg) {
    size_t wrote = 0;
    while (wrote < ALLDATA) {
        size_t ret;
        ret = circbuf_write(cb, data_buffer + wrote, ALLDATA - wrote);
        if (ret == 0) {
            continue;
        }
        wrote += ret;
    }
    circbuf_set_eof(cb);
}

// read data from circbuf and run fingerprinting on it, thereby
// generating chunks and adding them to an array
void* consumer_thread(void* arg) {
    size_t buf_size = 2*max_block_size;

    RabinPoly *rp;
   
    rp = rp_new(window_size,
                avg_block_size, min_block_size, max_block_size, buf_size);
    assert(rp);
    rp_from_circbuf(rp, cb);

    size_t* totalread = (size_t*)malloc(sizeof(size_t));
    while (1) {
        int res = rp_block_next(rp);
        if (res == -1) { // EOF
            break;
        }
        if (res == -2) { // BUFFER EMPTY
            continue;
        }

        blocks_dist[rp->block_size] += 1;
        *totalread += rp->block_size;
        circbuf_mark_consumed(cb, rp->block_size);
    }
    
    rp_free(rp);
    return totalread;
}

void fill_data_buffer() {
    int fd = open("/dev/urandom", O_RDONLY);
    FILE* stream = fopen("/dev/urandom", "r");

    data_buffer = (char*)malloc(sizeof(char) * ALLDATA);
    ssize_t have_read = 0;
    while (have_read < ALLDATA) {
        ssize_t ret;
        ret = fread(data_buffer, sizeof(char), ALLDATA - have_read, stream);
        if (ret < 0) {
            printf("error reading from urandom\n");
            return;
        }
        have_read += ret;
    }
    close(fd);
}

int main(int argc, char **argv){
    fill_data_buffer();
    blocks_dist = (size_t*)calloc(max_block_size, sizeof(size_t));

    cb = (struct circbuf*)malloc(sizeof(struct circbuf));
    init_circbuf(cb, 10*max_block_size);
    
    pthread_t prod_id, cons_id;
    printf("threads starting\n");
    pthread_create(&prod_id, NULL, &producer_thread, NULL);
    pthread_create(&cons_id, NULL, &consumer_thread, NULL);

    void* res;
    pthread_join(prod_id, NULL);
    pthread_join(cons_id, &res);
    printf("threads done\n");

    /* for (int i = 0; i < max_block_size; i++) { */
    /*     printf("SIZE: %d FREQ: %ld\n", i, blocks_dist[i]); */
    /* } */
    free(data_buffer);
    free(blocks_dist);
    free_circbuf(cb);
    free(cb);
    free(res);

    return 0;
}
