#include <assert.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <rabinpoly.h>
// #include <crypto.h>
#include <openssl/evp.h>
#include <fcntl.h>
#include <unistd.h>

// need to test the fingerprinting outside of LPFS because chunk sizes are not 
// what I expect
// Read 1MB data from /dev/urandom. Use `rp_from_buffer`. Measure the frequency
// of chunk sizes which are generated.

// http://stackoverflow.com/questions/10324611/how-to-calculate-the-md5-hash-of-a-large-file-in-c
// http://stackoverflow.com/questions/10129085/read-from-stdin-write-to-stdout-in-c

size_t* chunk_dist;

size_t time_diff_us(struct timespec* start, struct timespec* end) {
    return ((end->tv_sec - start->tv_sec) * (1000 * 1000)) + ((end->tv_nsec - start->tv_nsec) / 1000);
}

int main(int argc, char **argv){
    size_t totaldata = (1024 * 1024 * 128);
    EVP_MD_CTX *mdctx;
    EVP_MD* md = EVP_MD_fetch(NULL, "MD5", NULL);
    unsigned int md5_digest_len = EVP_MD_size(md);
    printf("digest len %d\n", md5_digest_len);
    unsigned char *digest = (unsigned char*)OPENSSL_malloc(md5_digest_len);

    int fd = open("/dev/urandom", O_RDONLY);
    FILE* stream = fopen("/dev/urandom", "r");
//    unsigned char* data = (unsigned char*)malloc(totaldata * sizeof(unsigned char));
//    int dataread = read(fd, data, totaldata);
//    assert(dataread == totaldata);

    unsigned int window_size = 32;
    size_t min_block_size = 1024;
    size_t avg_block_size = 4096;
    size_t max_block_size = 32768;
    size_t buf_size = totaldata;
    chunk_dist = (size_t*)calloc(max_block_size, sizeof(size_t));

    RabinPoly *rp;
   
    rp = rp_new(window_size,
                avg_block_size, min_block_size, max_block_size, buf_size);
    assert(rp);
//    rp_from_buffer(rp, data, totaldata);
    rp_from_stream(rp, stream);

    size_t totalread = 0;

    struct timespec start_finger, end_finger, start_md5, end_md5;

    size_t count = 0;
    size_t total_finger_us = 0;
    size_t total_md5_us = 0;
    mdctx = EVP_MD_CTX_new();
    while (totalread < totaldata) {
        clock_gettime(CLOCK_MONOTONIC, &start_finger);
        int rc = rp_block_next(rp);
        if (rc) {
            assert (rc == EOF);
            break;
        }
        clock_gettime(CLOCK_MONOTONIC, &end_finger);

        clock_gettime(CLOCK_MONOTONIC, &start_md5);
        EVP_DigestInit_ex(mdctx, md, NULL);
        EVP_DigestUpdate(mdctx, rp->block_addr, rp->block_size);
        EVP_DigestFinal_ex(mdctx, digest, &md5_digest_len);
        clock_gettime(CLOCK_MONOTONIC, &end_md5);

        count++;
        total_finger_us += time_diff_us(&start_finger, &end_finger);
        total_md5_us += time_diff_us(&start_md5, &end_md5);

        printf("%zu ", rp->block_size);
        chunk_dist[rp->block_size] += 1;
        for (size_t i = 0; i < md5_digest_len; i++) {
            printf("%02x", digest[i]);
        }
        printf("\n");
        totalread += rp->block_size;
    }
    printf("fingerprint avg: %ld md5 avg: %ld\n", total_finger_us / count, total_md5_us / count);

    /* for (size_t i = 0; i < max_block_size; i++) { */
    /*     printf("chunksz %ld freq %ld\n", i, chunk_dist[i]); */
    /* } */

//    close(fd);
//    free(data);
    EVP_MD_CTX_free(mdctx);
    free(chunk_dist);
    rp_free(rp);

    return 0;
}
