#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include "circbuf.h"

Circbuf::Circbuf(uint64_t sz) {
  pthread_mutex_init(&lock, NULL);
  buffer = (char*)calloc(sz, sizeof(char));
  buflen = sz;
  filled = 0;
  head = 0;
  tail = 0;
  eof = 0;
}

Circbuf::~Circbuf() {
    free(buffer);
}

// return the number of bytes available between (tail + offset) and head
size_t Circbuf::DataAvailable(size_t offset) {
  return filled;
}

// we add to (produce) at the head, and consume from (consume) at the tail
uint64_t Circbuf::Write(const char* buf, uint64_t len) {
  size_t have_written = 0;
  size_t step, max;
  while (have_written < len) {
    max = buflen - filled - 1;
    step = (max > buflen - head) ? buflen - head : max;
    if (step > (len - have_written)) { step = (len - have_written); }
    if (step > 0) {
      memcpy(buffer + head, buf + have_written, step);

      pthread_mutex_lock(&lock);
      head = (head + step) % buflen;
      filled += step;
      pthread_mutex_unlock(&lock);
      have_written += step;
    }
  }
  return have_written;
}

// read at most len bytes
// do not update tail, that is done in MarkConsumed
uint64_t Circbuf::Read(char* buf, uint64_t len) {
  while (len > filled) { ; }
  size_t have_read = 0;
  size_t curr = tail;
  while (have_read < len) {
    size_t max, step;
    if (curr <= head) {
      max = head - curr;
    } else {
      max = buflen - curr;
    }
    step = (len - have_read) < max ? (len - have_read) : max;
    memcpy(buf + have_read, buffer + curr, step);
    curr = (curr + step) % buflen;
    have_read += step;
  }
  return have_read;
}

void Circbuf::MarkConsumed(uint64_t len) {
  assert(len <= filled);
  pthread_mutex_lock(&lock);
  tail = (tail + len) % buflen;
  filled -= len;
  pthread_mutex_unlock(&lock);
}

void Circbuf::SetEof() {
  eof = 1;
}

void Circbuf::UnsetEof() {
  eof = 0;
}

int Circbuf::IsEof() {
  return eof;
}
