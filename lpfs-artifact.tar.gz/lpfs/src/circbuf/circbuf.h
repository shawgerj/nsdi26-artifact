#ifndef CIRCBUF_H
#define CIRCBUF_H

#include <stdint.h>
#include <string.h>
#include <pthread.h>

class Circbuf {
public:
    Circbuf(uint64_t sz);
    ~Circbuf();

    char* operator[](size_t idx) {
      size_t p = (tail + idx) % this->buflen;
      return (p == this->head) ? NULL : this->buffer + p;
    }

    uint64_t Write(const char* buf, uint64_t len);
    uint64_t Read(char* buf, uint64_t len);
    void MarkConsumed(uint64_t len);
    void SetEof();
    void UnsetEof();
    int IsEof();
    size_t DataAvailable(size_t offset);
    
private:
  pthread_mutex_t lock;
  uint64_t buflen;
  uint64_t head;
  uint64_t tail;
  uint64_t filled;
  int eof;
  
  char* buffer;
};

#endif
