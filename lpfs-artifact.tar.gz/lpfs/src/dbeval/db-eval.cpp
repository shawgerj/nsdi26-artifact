#include <random>
#include <string>
#include <iostream>
#include <unistd.h>
#include <fcntl.h>
#include "leveldb/db.h"
#include "leveldb/slice.h"

#define KEYLEN (16)
#define DBSIZE (32*1024*1024) // 32MB

const char* block_start = "DEADBEEF";
const char* block_end = "BAADF00D";
int valuesize;

leveldb::DB **dbs;

// https://stackoverflow.com/questions/440133/how-do-i-create-a-random-alpha-numeric-string-in-c
std::string random_string(std::string::size_type length) {
    static auto& chrs = "0123456789"
        "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

    thread_local static std::mt19937 rg{std::random_device{}()};
    thread_local static std::uniform_int_distribution<std::string::size_type> pick(0, sizeof(chrs) - 2);

    std::string s;

    s.reserve(length);

    while(length--)
        s += chrs[pick(rg)];

    return s;
}

void insert_keys(size_t numkeys, int numdbs, int hints) {
    char* key = (char*)malloc(KEYLEN * sizeof(char));

    for (size_t i = 0; i < numkeys; i++) {
        // insert to db1
        snprintf(key, KEYLEN, "KEY_%06ld", i);

        leveldb::Status s;
        std::string val;
        if (hints) {
            val = block_start + random_string(valuesize) + block_end;
        } else {
            val = random_string(valuesize);
        }
        
        s = dbs[0]->Put(leveldb::WriteOptions(), key, val);
        if (!s.ok()) {
            std::cout << "put failed: " << s.ToString() << std::endl;
        }

        // insert to db2 if we have it
        if (numdbs == 2) {
            std::string val2 = key + val;
            s = dbs[1]->Put(leveldb::WriteOptions(), key, val2);
            if (!s.ok()) {
                std::cout << "put failed: " << s.ToString() << std::endl;
            }
        }
    }

    std::cout << "done writing keys" << std::endl;
    free(key);
}


// usage: -n <numdbs (1|2)> -v <valuesize> -h (hint on|off)
int main(int argc, char* argv[]) {
    int numdbs;
    int hints = 0;
    int opt;

    while ((opt = getopt(argc, argv, "n:v:h")) != -1) {
        switch (opt) {
        case 'n':
            numdbs = atoi(optarg); // one or two
            if (numdbs > 2) {
                std::cout << "we only support 2 instances of leveldb" << std::endl;
                return 1;
            }
            break;
        case 'v':
            valuesize = atoi(optarg);
            break;
        case 'h':
            hints = 1;
            break;
        }
    }

    dbs = (leveldb::DB**)malloc(sizeof(leveldb::DB*) * numdbs);
    
    leveldb::Options options;
    options.create_if_missing = true;
    options.compression = leveldb::kNoCompression;

    for (int i = 0; i < numdbs; i++) {
      
      std::string path = std::string(PROJ_ROOT) + std::string("/mnt/db") + std::to_string(i);
        leveldb::Status status = leveldb::DB::Open(options, path, &(dbs[i]));
        assert(status.ok());
    }
    
    insert_keys(DBSIZE/(KEYLEN + valuesize), numdbs, hints);

    for (int i = 0; i < numdbs; i++) {
        delete dbs[i];
    }

    return 0;
}
